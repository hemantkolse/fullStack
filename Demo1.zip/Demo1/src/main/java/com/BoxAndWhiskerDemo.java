/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 *
 * ----------------------
 * BoxAndWhiskerDemo.java
 * ----------------------
 * (C) Copyright 2003, 2004, by David Browning and Contributors.
 *
 * Original Author:  David Browning (for the Australian Institute of Marine Science);
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: BoxAndWhiskerDemo.java,v 1.12 2004/06/02 14:35:42 mungady Exp $
 *
 * Changes
 * -------
 * 21-Aug-2003 : Version 1, contributed by David Browning (for the Australian Institute of 
 *               Marine Science);
 * 27-Aug-2003 : Renamed BoxAndWhiskerCategoryDemo --> BoxAndWhiskerDemo, moved dataset creation
 *               into the demo (DG);
 *
 */

package com;

import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.util.IOUtils;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFPictureData;
import org.apache.poi.xslf.usermodel.XSLFPictureShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.BoxAndWhiskerToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.chart.ui.ApplicationFrame;
import org.jfree.data.statistics.BoxAndWhiskerCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;


public class BoxAndWhiskerDemo extends ApplicationFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** Access to logging facilities. */
   // private static final LogContext LOGGER = Log.createContext(BoxAndWhiskerDemo.class);

    public BoxAndWhiskerDemo(final String title) throws IOException {
        super(title);           
    }

    private void createBoxAndWhiskerChartInPPT()
    {
    	 final BoxAndWhiskerCategoryDataset dataset = createSampleDataset();

         final CategoryAxis xAxis = new CategoryAxis("Type");
         final NumberAxis yAxis = new NumberAxis("Value");
         yAxis.setAutoRangeIncludesZero(false);
         final BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
         renderer.setFillBox(false);
         renderer.setDefaultToolTipGenerator(new BoxAndWhiskerToolTipGenerator());
         final CategoryPlot plot = new CategoryPlot(dataset, xAxis, yAxis, renderer);
         
         final JFreeChart chart = new JFreeChart(
             "Box-and-Whisker Demo",
             new Font("SansSerif", Font.BOLD, 14),
             plot,
             true
         );
                 
         //write chart instance in ppt file
             	
 		try {
 			 File file1 = new File("/home/administrator/Desktop/rakesh/example1");
 			ChartUtilities.saveChartAsPNG(file1, chart, 700, 500);
 			
 			XMLSlideShow ppt = new XMLSlideShow();
 	     	XSLFSlide slide = ppt.createSlide();
 	 		File file = new File("/home/administrator/Desktop/rakesh/example1.pptx");
 	 		FileOutputStream out;
 			out = new FileOutputStream(file);
 			
 			//reading an image
 			File image = new File("/home/administrator/Desktop/rakesh/example1");

 			//converting it into a byte array
 			byte[] picture = IOUtils.toByteArray(new FileInputStream(file1));
 			
 			System.out.println(picture);
 			
 			int idx=ppt.addPicture(picture, XSLFPictureData.PICTURE_TYPE_PNG);
 			Dimension dimension=new Dimension(700, 500);
 			ppt.setPageSize(dimension);
 			
 			XSLFPictureShape pic = slide.createPicture(idx);
 			slide.createPicture(idx);
 			
 			ppt.write(out);
 			
 			
 		} catch (FileNotFoundException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
 		catch (IOException e)
 		{
 		// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    }
    
    /**
     * Creates a sample dataset.
     * 
     * @return A sample dataset.
     */
    private BoxAndWhiskerCategoryDataset createSampleDataset() {
        
        final int seriesCount = 3;
        final int categoryCount = 4;
        final int entityCount = 22;
        
        final DefaultBoxAndWhiskerCategoryDataset dataset 
            = new DefaultBoxAndWhiskerCategoryDataset();
        for (int i = 0; i < seriesCount; i++) {
            for (int j = 0; j < categoryCount; j++) {
                final List list = new ArrayList();
                // add some values...
                for (int k = 0; k < entityCount; k++) {
                    final double value1 = 10.0 + Math.random() * 3;
                    list.add(new Double(value1));
                    final double value2 = 11.25 + Math.random(); // concentrate values in the middle
                    list.add(new Double(value2));
                }
               // LOGGER.debug("Adding series " + i);
               // LOGGER.debug(list.toString());
                dataset.add(list, "Series " + i, " Type " + j);
            }
                   }
        return dataset;
    }

    public static void main(final String[] args) throws IOException {

        //Log.getInstance().addTarget(new PrintStreamLogTarget(System.out));
        final BoxAndWhiskerDemo demo = new BoxAndWhiskerDemo("Box-and-Whisker Chart Demo");
        demo.createBoxAndWhiskerChartInPPT();
     //  to show in jwt format
        // demo.pack();
        // RefineryUtilities.centerFrameOnScreen(demo);
        // demo.setVisible(true);
   }
}
